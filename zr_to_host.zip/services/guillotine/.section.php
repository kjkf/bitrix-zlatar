<?
$sSectionName = "Гильотина";
$arDirProperties = Array(

);
?>