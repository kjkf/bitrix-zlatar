<?
$sSectionName = "Аргонная сварка";
$arDirProperties = Array(

);
?>