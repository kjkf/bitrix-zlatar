<?
$sSectionName = "Плазменная резка";
$arDirProperties = Array(

);
?>