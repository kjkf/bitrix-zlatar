<?
$sSectionName = "Гидрообразивная резка";
$arDirProperties = Array(

);
?>