<?
$sSectionName = "Листогиб";
$arDirProperties = Array(

);
?>