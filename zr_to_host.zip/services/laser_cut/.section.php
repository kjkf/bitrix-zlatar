<?
$sSectionName = "Лазерная резка";
$arDirProperties = Array(

);
?>