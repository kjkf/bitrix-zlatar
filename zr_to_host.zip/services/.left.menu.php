<?
$aMenuLinks = Array(
	Array(
		"Лазерная резка", 
		"/services/laser_cut/",
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Гидрообразивная резка", 
		"/services/waterjet_cut/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Плазменная резка", 
		"/services/plasma_cut/",
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Листогиб", 
		"/services/listogib/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Гильотина", 
		"/services/guillotine/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Аргонная сварка", 
		"/services/argon_welding/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>