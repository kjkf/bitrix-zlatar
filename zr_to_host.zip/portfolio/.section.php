<?
$sSectionName = "Портфолио";
$arDirProperties = Array(

);
?>