<?
$aMenuLinks = Array(
	Array(
		"Руководители", 
		"/leaders/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Подразделения", 
		"/subdivision/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>