<?
$sSectionName = "Руководители";
$arDirProperties = Array(

);
?>