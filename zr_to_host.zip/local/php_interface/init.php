<?php
function debug($data){
   # echo 'HI2!';
    echo '<pre>' . print_r($data, 1) . '</pre>';
}
