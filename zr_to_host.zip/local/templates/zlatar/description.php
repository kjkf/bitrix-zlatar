<?php
/**
 * Created by IntelliJ IDEA.
 * User: yakjk
 * Date: 04.08.2020
 * Time: 13:45
 */

$arTemplate = [
    'NAME' => 'Шаблон сайта Златарь',
    'DESCRIPTION' => 'Основной шаблон'
];