<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters = array(
	"USE_ICON" => Array(
		"NAME" => GetMessage("PBMFP_USE_ICON"),
		"TYPE" => "LIST",
		"PARENT" => "BASE",
		"VALUES" => array(GetMessage('PBMFP_USE_ICON_1'),GetMessage('PBMFP_USE_ICON_2')),
	),
);
?>
