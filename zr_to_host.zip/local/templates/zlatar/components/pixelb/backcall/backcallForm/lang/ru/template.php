<?
$MESS['PBMF_SERVICES_FORM_NAME_LABEL'] = 'ЗАЯВКА НА ЗВОНОК';
$MESS['PBMF_SERVICES_NAME_LABEL'] = 'Ваше имя:';
$MESS['PBMF_SERVICES_MAIL_LABEL'] = 'Ваш e-mail:';
$MESS['PBMF_SERVICES_PHONE_LABEL'] = 'Номер Вашего телефона:';
$MESS['PBMF_SERVICES_COMMENTS_LABEL'] = 'Сообщение';
$MESS['PBMF_SERVICES_CAPCHA_LABEL'] = 'Код';
$MESS['PBMF_SERVICES_SUBMIT_LABEL'] = 'ОТПРАВИТЬ ЗАЯВКУ';
$MESS['TRIGGER_LABEL'] = 'Обратный звонок';
$MESS['ORDER_CALLBACK_LABEL'] = 'Заказать обратный звонок';
$MESS['PB_FORM_RULES_LABEL_1'] = 'Нажимая на кнопку ';
$MESS['PB_FORM_RULES_LABEL_2'] = ', я даю ';
$MESS['PB_FORM_RULES_LABEL_3'] = 'согласие на обработку персональных данных';
?>
