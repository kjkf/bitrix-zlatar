<?
$MESS['LABEL_FORM_WIDTH'] = 'Ширина формы поо правилам CSS в px или %';
$MESS['PBMFP_USE_ICON'] = 'Использовать иконку';
$MESS['PBMFP_USE_ICON_1'] = 'обратного звонка';
$MESS['PBMFP_USE_ICON_2'] = 'сообщения';
?>
