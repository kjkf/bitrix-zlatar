<?
$sSectionName = "Навесные вентилируемые фасады";
$arDirProperties = Array(

);
?>