<?
$aMenuLinks = Array(
	Array(
		"Малые архитектурные формы", 
		"/products/small_forms/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Навесные вентилируемые фасады", 
		"/products/suspended-facades/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Прочие", 
		"/products/others/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>