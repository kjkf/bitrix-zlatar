<?
$sSectionName = "Продукты";
$arDirProperties = Array(

);
?>