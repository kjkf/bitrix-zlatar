<?
$sSectionName = "Малые архитектурные формы";
$arDirProperties = Array(

);
?>