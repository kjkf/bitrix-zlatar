<?
$sSectionName = "Прочие";
$arDirProperties = Array(

);
?>