<?
$sSectionName = "Подразделения";
$arDirProperties = Array(

);
?>